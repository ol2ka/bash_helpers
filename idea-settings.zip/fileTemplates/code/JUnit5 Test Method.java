@org.junit.jupiter.api.Test
void ${NAME}() throws Exception {
  ${BODY}
}