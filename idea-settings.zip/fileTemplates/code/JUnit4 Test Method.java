@org.junit.Test
public void ${NAME}() throws Exception {
  ${BODY}
}